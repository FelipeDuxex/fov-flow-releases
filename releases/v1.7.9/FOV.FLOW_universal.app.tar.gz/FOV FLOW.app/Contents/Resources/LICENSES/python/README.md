# Notices da base Python macOS arm64

Preservar os textos upstream completos ao redistribuir esta base. A licença do projeto de build não representa a licença de todo o runtime: CPython, pip e bibliotecas incorporadas têm avisos e condições próprios. `PYTHON.json` descreve a distribuição e suas extensões; ele apoia a seleção, mas não substitui os textos de licença. [Astral: licenças das distribuições](https://gregoryszorc.com/docs/python-build-standalone/main/running.html#licensing), [Formato do metadata](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html#python-json), [Licença CPython](https://docs.python.org/3.12/license.html)

## Origem autenticada

O runtime selecionado é `cpython-3.12.15+20261003-aarch64-apple-darwin-install_only.tar.gz`, SHA-256 `316a463172740e71d8dca1f2730784e325f3f720941137b5d674d5801a632213`, 25146462 bytes. O inventário do runtime é `1202dcc11b2209fe9fe453cd362a5d47eaaf9ddde2b80886720aa4b022f331cf`.

Para recuperar metadata e licenças omitidos pelo formato `install_only`, foi obtido o archive full correspondente da mesma release/build:

| Campo | Valor |
| --- | --- |
| Arquivo | `cpython-3.12.15+20261003-aarch64-apple-darwin-pgo+lto-full.tar.zst` |
| URL | [Asset full 20261003](https://github.com/astral-sh/python-build-standalone/releases/download/20261003/cpython-3.12.15%2B20261003-aarch64-apple-darwin-pgo%2Blto-full.tar.zst) |
| SHA-256 | `a23a0baff73a5f10c820841cc1889a5b7fc12048fe8c0622f6a481ab82ea367b` |
| Bytes | `55001420` |
| Source/build commit | `5e46737f6480fc315ebfea83866910cbfcc772f0` |
| Conteúdo extraído nesta preparação | Somente `python/PYTHON.json` e `python/licenses/*` |

O full é evidência de metadata/notices; não é o archive selecionado para instalar a base. As attestations da release/build registram os digests dos dois assets. O formato [install_only](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html#install-only-archive) leva a instalação, sem `PYTHON.json` nem artefatos de build do full.

## Textos a preservar

O diretório isolado `full-license-metadata/python/licenses/` contém estes 19 arquivos. O integrador copiará todos, intactos, para `docs/cortex-python-notices/`. O conjunto é deliberadamente inclusivo: nomes como X11, BDB e OpenSSL 1.1 não afirmam que todos esses componentes estão usados ou carregados no runtime Mac selecionado. Preservar o conjunto upstream evita perder atribuições ao estreitar prematuramente a seleção.

| Arquivo | Bytes |
| --- | ---: |
| `LICENSE.bdb.txt` | 7293 |
| `LICENSE.bzip2.txt` | 1743 |
| `LICENSE.cpython.txt` | 36164 |
| `LICENSE.expat.txt` | 1144 |
| `LICENSE.libedit.txt` | 1614 |
| `LICENSE.libffi.txt` | 1132 |
| `LICENSE.liblzma.txt` | 660 |
| `LICENSE.libuuid.txt` | 1432 |
| `LICENSE.libX11.txt` | 47018 |
| `LICENSE.libXau.txt` | 1148 |
| `LICENSE.libxcb.txt` | 1337 |
| `LICENSE.mpdecimal.txt` | 1284 |
| `LICENSE.ncurses.txt` | 1447 |
| `LICENSE.openssl-1.1.txt` | 6120 |
| `LICENSE.openssl-3.txt` | 10175 |
| `LICENSE.sqlite.txt` | 1481 |
| `LICENSE.tcl.txt` | 2255 |
| `LICENSE.tix.txt` | 2826 |
| `LICENSE.zlib.txt` | 995 |

Preservar também os notices CPython/pip já incluídos na própria base e no wheel pip autenticado. Não remover, resumir ou substituir esses textos por este README. Registrar as transformações locais de aliases para cópias e de modos 0664/0775 para 0644/0755; qualquer mudança adicional de bytes, assinatura ou componentes precisa de documentação própria e novos pins/inventário quando aplicável.

## Entrega ao cliente: responsabilidade da distribuição

Arquivos presentes apenas em `docs/cortex-python-notices/` no repositório não garantem entrega ao cliente. O dono de distribuição deve empacotar os 19 textos intactos e este aviso em recursos do app ou em `version/notices/python/`, incluir seus digests no manifest/fingerprint assinado e conferir o conteúdo do pacote final. Empacotar `PYTHON.json` junto como evidência de seleção facilita a auditoria.

Manter notices externos fora de `base/python/`: a árvore da base tem inventário exato e arquivos adicionais são recusados. Os avisos que já pertencem ao runtime upstream permanecem onde estão. A verificação de entrega deve comparar bytes/digests do pacote com os textos extraídos autenticados; o smoke Python não realiza esse gate.

Esta rodada preparou documentação e metadata isolados para handoff ao worktree de integração. Mesmo após a cópia local, integração no projeto original, empacotamento cliente, assinatura, notarização e QA Mac continuam sob os owners de integração/distribuição.
