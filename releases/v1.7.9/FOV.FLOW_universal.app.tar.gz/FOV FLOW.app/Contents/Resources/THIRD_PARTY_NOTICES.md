# Third-party notices

## Twemoji

The mascot emoji graphics use **Twemoji 17.0.3**, maintained by the
[jdecked/Twemoji contributors](https://github.com/jdecked/twemoji).

The graphics are licensed under
[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
The application loads the unmodified SVG assets from the version-pinned
jsDelivr mirror of the upstream repository.

Twemoji copyright belongs to its respective contributors.

## Inter

The Flow frontend and Cortex web interface use the Inter typeface, copyright
2016 The Inter Project Authors (https://github.com/rsms/inter).

The unmodified font files are distributed from `@fontsource-variable/inter`
version 5.3.0 under the SIL Open Font License 1.1. The Cortex web interface
includes the normal Latin variable font (weights 100–900) as
`cortex/engine/PLATAFORMA/web/flow-inter.woff2`.

The complete license is included in `LICENSES/Inter-OFL-1.1.txt` in the Flow
application resources and alongside the Cortex font as `flow-inter-LICENSE.txt`.
